import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class BmsColors {
  static const navy = Color(0xFF0D294D);
  static const blue = Color(0xFF157EC8);
  static const teal = Color(0xFF16A59C);
  static const pale = Color(0xFFF3F8FC);
  static const ink = Color(0xFF183452);
  static const muted = Color(0xFF72859A);
  static const border = Color(0xFFE2EDF5);
}

ThemeData buildBmsTheme() {
  final base = ThemeData(useMaterial3: true, brightness: Brightness.light);
  return base.copyWith(
    scaffoldBackgroundColor: BmsColors.pale,
    colorScheme: ColorScheme.fromSeed(seedColor: BmsColors.blue, primary: BmsColors.blue, secondary: BmsColors.teal, surface: Colors.white),
    textTheme: GoogleFonts.plusJakartaSansTextTheme(base.textTheme).apply(bodyColor: BmsColors.ink, displayColor: BmsColors.navy),
    inputDecorationTheme: InputDecorationTheme(
      filled: true, fillColor: const Color(0xFFF6F9FC),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 17),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: BmsColors.border)),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: BmsColors.border)),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(style: ElevatedButton.styleFrom(
      backgroundColor: BmsColors.blue, foregroundColor: Colors.white,
      minimumSize: const Size.fromHeight(54),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      textStyle: const TextStyle(fontWeight: FontWeight.w800),
    )),
  );
}

BoxDecoration softCard({double radius = 22}) => BoxDecoration(
  color: Colors.white,
  borderRadius: BorderRadius.circular(radius),
  border: Border.all(color: BmsColors.border),
  boxShadow: const [BoxShadow(color: Color(0x0F1E638A), blurRadius: 24, offset: Offset(0, 10))],
);
