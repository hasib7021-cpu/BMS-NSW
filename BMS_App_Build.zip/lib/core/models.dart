class Member {
  final int id;
  final String name, email, role, membership, photo;
  final bool canVote;
  const Member({required this.id, required this.name, required this.email, required this.role, required this.membership, this.photo = '', this.canVote = false});
  bool get isAdmin => role == 'admin' || role == 'super_admin';
  bool get isSuperAdmin => role == 'super_admin';
  factory Member.fromJson(Map<String, dynamic> m) => Member(
    id: (m['id'] as num?)?.toInt() ?? 0, name: '${m['name'] ?? 'Member'}',
    email: '${m['email'] ?? ''}', role: '${m['role'] ?? 'member'}',
    membership: '${m['membership'] ?? 'Membership'}', photo: '${m['photo'] ?? ''}',
    canVote: m['can_vote'] == true,
  );
}

class FeedItem {
  final int id;
  final String title, subtitle, date, image, category;
  const FeedItem({required this.id, required this.title, required this.subtitle, required this.date, required this.image, required this.category});
  factory FeedItem.fromJson(Map<String, dynamic> j) => FeedItem(
    id: (j['id'] as num?)?.toInt() ?? 0,
    title: '${j['title'] ?? ''}', subtitle: '${j['subtitle'] ?? ''}',
    date: '${j['date'] ?? ''}', image: '${j['image'] ?? ''}', category: '${j['category'] ?? ''}',
  );
}

class DashboardData {
  final List<FeedItem> events, news, alerts;
  const DashboardData({this.events = const [], this.news = const [], this.alerts = const []});
  factory DashboardData.fromJson(Map<String, dynamic> m) {
    List<FeedItem> read(String key) => (m[key] is List ? m[key] as List : [])
        .whereType<Map>().map((e) => FeedItem.fromJson(Map<String, dynamic>.from(e))).toList();
    return DashboardData(events: read('events'), news: read('news'), alerts: read('alerts'));
  }
}

class DemoContent {
  static const member = Member(id: 0, name: 'BMS NSW Member', email: 'preview@bms-nsw.com.au', role: 'member', membership: 'Lifetime Membership', canVote: true);
  static const admin = Member(id: 0, name: 'BMS NSW Administrator', email: 'admin-preview@bms-nsw.com.au', role: 'super_admin', membership: 'Lifetime Membership', canVote: true);
  static const dashboard = DashboardData(
    events: [
      FeedItem(id: 1, title: 'Annual Scientific Symposium', subtitle: 'Professional learning & community networking', date: 'Upcoming', image: '', category: 'Scientific'),
      FeedItem(id: 2, title: 'Community Networking Evening', subtitle: 'Connect with fellow BMS NSW doctors', date: 'To be announced', image: '', category: 'Community'),
    ],
    news: [
      FeedItem(id: 1, title: 'Welcome to the BMS NSW Member App', subtitle: 'All your membership services in one place.', date: 'Preview content', image: '', category: 'Announcement'),
      FeedItem(id: 2, title: 'Explore events, news and professional connections', subtitle: 'Stay connected with your medical community.', date: 'Preview content', image: '', category: 'Community'),
    ],
    alerts: [FeedItem(id: 1, title: 'Notifications will appear here', subtitle: 'Enable notifications after production setup.', date: '', image: '', category: 'Alert')],
  );
}
