import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import 'models.dart';

/// Override at build time: --dart-define=BMS_API_BASE=https://your-domain/app-api.php
const apiBase = String.fromEnvironment('BMS_API_BASE', defaultValue: 'https://bms-nsw.com.au/app-api.php');
const websiteBase = 'https://bms-nsw.com.au';

class ApiException implements Exception {
  final String message;
  ApiException(this.message);
  @override String toString() => message;
}

class BmsApi {
  final _client = http.Client();
  final _store = const FlutterSecureStorage();
  String? _session;
  bool get hasSession => _session != null && _session!.isNotEmpty;
  String? get sessionCookie => _session;

  Future<void> restore() async { _session = await _store.read(key: 'bms_php_session'); }

  Uri _uri(String action) => Uri.parse(apiBase).replace(queryParameters: {'action': action});
  Map<String, String> get _headers => {
    'Accept': 'application/json', 'Content-Type': 'application/json',
    if (hasSession) 'Cookie': 'PHPSESSID=$_session',
  };

  Future<Map<String, dynamic>> _get(String action) async {
    final response = await _client.get(_uri(action), headers: _headers).timeout(const Duration(seconds: 18));
    return _parse(response);
  }

  Map<String, dynamic> _parse(http.Response response) {
    Map<String, dynamic> result;
    try { result = Map<String, dynamic>.from(jsonDecode(response.body) as Map); }
    catch (_) { throw ApiException('The server is not ready for the app yet. Please install app-api.php.'); }
    if (response.statusCode >= 400 || result['ok'] != true) {
      throw ApiException('${result['error'] ?? 'Unable to connect. Please try again.'}');
    }
    return result;
  }

  Future<Member> login(String email, String password) async {
    final response = await _client.post(_uri('login'), headers: _headers,
      body: jsonEncode({'email': email, 'password': password})).timeout(const Duration(seconds: 18));
    final data = _parse(response);
    final cookie = response.headers['set-cookie'] ?? '';
    final match = RegExp(r'PHPSESSID=([^;,\s]+)').firstMatch(cookie);
    if (match == null) throw ApiException('Secure session cookie missing from server response.');
    _session = match.group(1);
    await _store.write(key: 'bms_php_session', value: _session);
    return Member.fromJson(Map<String, dynamic>.from(data['member'] as Map));
  }

  Future<Member> me() async {
    final data = await _get('me');
    return Member.fromJson(Map<String, dynamic>.from(data['member'] as Map));
  }

  Future<DashboardData> dashboard() async {
    final data = await _get('dashboard');
    return DashboardData.fromJson(data);
  }

  Future<void> logout() async {
    try { await _client.post(_uri('logout'), headers: _headers).timeout(const Duration(seconds: 6)); }
    catch (_) { /* Clear the local credential even if the network is offline. */ }
    _session = null;
    await _store.delete(key: 'bms_php_session');
  }

  void dispose() => _client.close();
}
