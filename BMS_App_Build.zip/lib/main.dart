import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'core/api.dart';
import 'core/models.dart';
import 'core/theme.dart';
import 'screens/login.dart';
import 'screens/app_shell.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const BmsApp());
}

class BmsApp extends StatefulWidget {
  const BmsApp({super.key});
  @override State<BmsApp> createState() => _BmsAppState();
}

class _BmsAppState extends State<BmsApp> {
  final api = BmsApi();
  Member? member;
  bool demo = false, loading = true;

  @override void initState() { super.initState(); _restore(); }
  Future<void> _restore() async {
    try {
      await api.restore();
      if (api.hasSession) {
        final m = await api.me();
        if (mounted) setState(() => member = m);
      }
    } catch (_) { /* Invalid or expired session returns to login. */ }
    finally { if (mounted) setState(() => loading = false); }
  }

  Future<void> _logout() async {
    await WebViewCookieManager().clearCookies();
    if (!demo) await api.logout();
    if (mounted) setState(() { member = null; demo = false; });
  }

  @override void dispose() { api.dispose(); super.dispose(); }

  @override Widget build(BuildContext context) => MaterialApp(
    title: 'BMS NSW Members', theme: buildBmsTheme(), debugShowCheckedModeBanner: false,
    home: loading ? const _Splash() : member == null
      ? LoginScreen(api: api, onLogin: (m, d) => setState(() { member = m; demo = d; }))
      : AppShell(member: member!, api: api, demo: demo, onLogout: _logout),
  );
}

class _Splash extends StatelessWidget {
  const _Splash();
  @override Widget build(BuildContext context) => Scaffold(
    body: Container(
      decoration: const BoxDecoration(gradient: LinearGradient(colors: [Color(0xFF10365D), Color(0xFF1586BF), Color(0xFF15A69B)],
        begin: Alignment.topLeft, end: Alignment.bottomRight)),
      child: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 132, height: 132, padding: const EdgeInsets.all(15),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(32),
            boxShadow: const [BoxShadow(color: Color(0x33000000), blurRadius: 32, offset: Offset(0, 15))]),
          child: Image.asset('assets/images/bms_logo.png')),
        const SizedBox(height: 25),
        const Text('BMS NSW', style: TextStyle(fontSize: 32, fontWeight: FontWeight.w900, color: Colors.white)),
        const SizedBox(height: 7),
        const Text('YOUR COMMUNITY. CONNECTED.', style: TextStyle(fontSize: 10, letterSpacing: 2.1, color: Colors.white70)),
        const SizedBox(height: 28),
        const SizedBox(width: 26, height: 26, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.4)),
      ])),
    ),
  );
}
