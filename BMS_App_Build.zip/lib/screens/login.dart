import 'package:flutter/material.dart';
import '../core/api.dart';
import '../core/models.dart';
import '../core/theme.dart';
import 'widgets.dart';

const enableDemo = bool.fromEnvironment('ENABLE_DEMO', defaultValue: false);

class LoginScreen extends StatefulWidget {
  final BmsApi api;
  final void Function(Member member, bool demo) onLogin;
  const LoginScreen({super.key, required this.api, required this.onLogin});
  @override State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final email = TextEditingController();
  final password = TextEditingController();
  bool loading = false, showPassword = false;
  String? error;

  Future<void> submit() async {
    if (email.text.trim().isEmpty || password.text.isEmpty) {
      setState(() => error = 'Enter your email and password.'); return;
    }
    setState(() { loading = true; error = null; });
    try {
      final member = await widget.api.login(email.text.trim(), password.text);
      if (mounted) widget.onLogin(member, false);
    } catch (e) {
      if (mounted) setState(() => error = e is ApiException ? e.message : 'Connection failed. Check your internet and API setup.');
    } finally { if (mounted) setState(() => loading = false); }
  }

  @override void dispose() { email.dispose(); password.dispose(); super.dispose(); }

  @override Widget build(BuildContext context) => Scaffold(
    body: BmsBackground(child: SafeArea(child: Center(child: ConstrainedBox(
      constraints: const BoxConstraints(maxWidth: 440),
      child: SingleChildScrollView(padding: const EdgeInsets.all(25), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const SizedBox(height: 16),
        Center(child: Container(width: 106, height: 106, padding: const EdgeInsets.all(13),
          decoration: softCard(radius: 29), child: Image.asset('assets/images/bms_logo.png'))),
        const SizedBox(height: 26),
        const Text('Welcome back', textAlign: TextAlign.center,
          style: TextStyle(fontSize: 31, fontWeight: FontWeight.w900, color: BmsColors.navy)),
        const SizedBox(height: 8),
        const Text('Your BMS NSW community, in your pocket.', textAlign: TextAlign.center,
          style: TextStyle(fontSize: 12.5, color: BmsColors.muted)),
        const SizedBox(height: 32),
        Container(padding: const EdgeInsets.all(24), decoration: softCard(radius: 27), child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const Text('MEMBER SIGN IN', style: TextStyle(fontSize: 11, color: BmsColors.blue, fontWeight: FontWeight.w900, letterSpacing: 1.6)),
          const SizedBox(height: 20),
          TextField(controller: email, keyboardType: TextInputType.emailAddress, autofillHints: const [AutofillHints.email],
            decoration: const InputDecoration(prefixIcon: Icon(Icons.mail_outline_rounded), labelText: 'Email address')),
          const SizedBox(height: 13),
          TextField(controller: password, obscureText: !showPassword, autofillHints: const [AutofillHints.password],
            onSubmitted: (_) => submit(),
            decoration: InputDecoration(prefixIcon: const Icon(Icons.lock_outline_rounded), labelText: 'Password',
              suffixIcon: IconButton(onPressed: () => setState(() => showPassword = !showPassword),
                icon: Icon(showPassword ? Icons.visibility_off_outlined : Icons.visibility_outlined)))),
          if (error != null) Padding(padding: const EdgeInsets.only(top: 12),
            child: Text(error!, style: const TextStyle(color: Colors.redAccent, fontSize: 12))),
          const SizedBox(height: 22),
          ElevatedButton(onPressed: loading ? null : submit, child: loading
            ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
            : const Row(mainAxisAlignment: MainAxisAlignment.center, children: [Text('Sign in to Member Portal'), SizedBox(width: 9), Icon(Icons.arrow_forward_rounded)])),
          const SizedBox(height: 8),
          if (enableDemo) ...[
            TextButton(onPressed: () => widget.onLogin(DemoContent.member, true),
              child: const Text('Preview as Member  →')),
            TextButton(onPressed: () => widget.onLogin(DemoContent.admin, true),
              child: const Text('Preview as Super Admin  →')),
          ],
        ])),
        const SizedBox(height: 23),
        if (enableDemo) const Text('Demo mode uses sample content and never accesses the live database.',
          textAlign: TextAlign.center, style: TextStyle(color: BmsColors.muted, fontSize: 10)),
        const SizedBox(height: 16),
        const Center(child: Text('BANGLADESH MEDICAL SOCIETY OF NSW',
          style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.1, color: BmsColors.muted, fontSize: 9))),
      ])),
    )))),
  );
}
