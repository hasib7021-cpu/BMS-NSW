import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import '../core/api.dart';
import '../core/theme.dart';

class PortalWebScreen extends StatefulWidget {
  final String title, path;
  final String? sessionCookie;
  final bool demo;
  const PortalWebScreen({super.key, required this.title, required this.path, required this.sessionCookie, required this.demo});
  @override State<PortalWebScreen> createState() => _PortalWebScreenState();
}

class _PortalWebScreenState extends State<PortalWebScreen> {
  WebViewController? controller;
  bool loading = true;
  @override void initState() { super.initState(); if (!widget.demo) _start(); }

  Future<void> _start() async {
    try {
      if (widget.sessionCookie != null) {
        await WebViewCookieManager().setCookie(WebViewCookie(
          name: 'PHPSESSID', value: widget.sessionCookie!, domain: 'bms-nsw.com.au', path: '/'));
      }
      final web = WebViewController()
        ..setJavaScriptMode(JavaScriptMode.unrestricted)
        ..setBackgroundColor(Colors.white)
        ..setNavigationDelegate(NavigationDelegate(
          onPageStarted: (_) { if (mounted) setState(() => loading = true); },
          onPageFinished: (_) { if (mounted) setState(() => loading = false); },
          onWebResourceError: (error) { if (mounted && error.isForMainFrame == true) setState(() => loading = false); },
          onNavigationRequest: (request) {
            final uri = Uri.tryParse(request.url);
            if (uri == null || uri.scheme != 'https') return NavigationDecision.prevent;
            final host = uri.host.toLowerCase();
            if (host == 'bms-nsw.com.au' || host == 'www.bms-nsw.com.au' ||
                host == 'checkout.stripe.com' || host == 'stripe.com' || host.endsWith('.stripe.com')) {
              return NavigationDecision.navigate;
            }
            launchUrl(uri, mode: LaunchMode.externalApplication);
            return NavigationDecision.prevent;
          },
        ));
      if (!mounted) return;
      setState(() => controller = web);
      final url = Uri.parse('$websiteBase/${widget.path.startsWith('/') ? widget.path.substring(1) : widget.path}');
      await web.loadRequest(url);
    } catch (_) { if (mounted) setState(() => loading = false); }
  }

  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(backgroundColor: Colors.white, title: Text(widget.title,
      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: BmsColors.navy)),
      actions: [if (controller != null) IconButton(onPressed: () => controller?.reload(), icon: const Icon(Icons.refresh_rounded))]),
    body: widget.demo ? Center(child: Padding(padding: const EdgeInsets.all(30), child: Column(
      mainAxisSize: MainAxisSize.min, children: [
        const Icon(Icons.lock_outline_rounded, color: BmsColors.blue, size: 54),
        const SizedBox(height: 15),
        Text(widget.title, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900)),
        const SizedBox(height: 10),
        const Text('This feature opens the real BMS NSW member portal after you sign in. Demo mode never changes live data.', textAlign: TextAlign.center),
      ]))) : Stack(children: [
      if (controller != null) WebViewWidget(controller: controller!),
      if (loading) const LinearProgressIndicator(minHeight: 3),
    ]),
  );
}
