import 'package:flutter/material.dart';
import '../core/models.dart';

class MenuEntry {
  final String title, route;
  final IconData icon;
  final bool admin, superAdmin, vote;
  const MenuEntry(this.title, this.route, this.icon, {this.admin = false, this.superAdmin = false, this.vote = false});
  bool allowed(Member member) => (!admin || member.isAdmin) && (!superAdmin || member.isSuperAdmin) && (!vote || member.canVote);
}

class MenuGroup {
  final String title, subtitle;
  final List<MenuEntry> entries;
  const MenuGroup(this.title, this.subtitle, this.entries);
}

const menuGroups = [
  MenuGroup('YOUR COMMUNITY', 'Connect, discover and contribute', [
    MenuEntry('My Feed', 'home', Icons.space_dashboard_rounded),
    MenuEntry('Mentors', 'mentors', Icons.school_rounded),
    MenuEntry('Jobs', 'jobs', Icons.work_outline_rounded),
    MenuEntry('Business', 'business', Icons.storefront_rounded),
    MenuEntry('Insight', 'insight', Icons.lightbulb_outline_rounded),
  ]),
  MenuGroup('MEMBERS & CONNECTIONS', 'People and conversations', [
    MenuEntry('Browse Members', 'members', Icons.groups_rounded),
    MenuEntry('Messages', 'messages', Icons.chat_bubble_outline_rounded),
    MenuEntry('Connections', 'connections', Icons.handshake_outlined),
    MenuEntry('Committee', 'committee', Icons.account_tree_outlined),
    MenuEntry('My Profile', 'profile', Icons.person_outline_rounded),
  ]),
  MenuGroup('WHAT\'S HAPPENING', 'News, activities and causes', [
    MenuEntry('Events', 'events', Icons.event_available_outlined),
    MenuEntry('News', 'news', Icons.newspaper_rounded),
    MenuEntry('Fundraisings', 'fundraisings', Icons.volunteer_activism_outlined),
    MenuEntry('Photo Gallery', 'gallery', Icons.photo_library_outlined),
    MenuEntry('Notifications', 'alerts', Icons.notifications_active_outlined),
  ]),
  MenuGroup('MEMBERSHIP & VOTING', 'Manage your membership', [
    MenuEntry('Membership', 'membership', Icons.workspace_premium_outlined),
    MenuEntry('Renewal', 'membership', Icons.autorenew_rounded),
    MenuEntry('Voting', 'elections', Icons.how_to_vote_outlined, vote: true),
    MenuEntry('Event Tickets', 'events', Icons.confirmation_number_outlined),
    MenuEntry('Donations', 'fundraisings', Icons.favorite_outline_rounded),
  ]),
  MenuGroup('ACCOUNT & SETTINGS', 'Keep your information up to date', [
    MenuEntry('Update Profile', 'profile', Icons.manage_accounts_outlined),
    MenuEntry('Change Email', 'settings', Icons.alternate_email_rounded),
    MenuEntry('Password', 'change-password', Icons.password_rounded),
    MenuEntry('Settings', 'settings', Icons.tune_rounded),
  ]),
  MenuGroup('ADMINISTRATION', 'Only visible to authorized admins', [
    MenuEntry('Admin Panel', 'admin', Icons.admin_panel_settings_outlined, admin: true),
    MenuEntry('Members', 'manage-members', Icons.group_add_outlined, admin: true),
    MenuEntry('Applications', 'admin-applications', Icons.assignment_turned_in_outlined, admin: true),
    MenuEntry('Email Centre', 'admin-email-centre', Icons.mark_email_unread_outlined, admin: true),
    MenuEntry('Member Profiles', 'member-profiles', Icons.edit_note_outlined, admin: true),
    MenuEntry('Committees', 'committee-management', Icons.account_tree_rounded, admin: true),
    MenuEntry('Manage Events', 'manage-events', Icons.event_note_outlined, admin: true),
    MenuEntry('Manage News', 'admin', Icons.newspaper_rounded, admin: true),
    MenuEntry('Fundraisings', 'manage-fundraisings', Icons.handshake_outlined, admin: true),
    MenuEntry('Elections', 'manage-elections', Icons.ballot_outlined, admin: true),
    MenuEntry('Homepage Scroller', 'scroller-admin', Icons.view_carousel_outlined, admin: true),
    MenuEntry('Power Admin', 'power-admin', Icons.verified_user_outlined, superAdmin: true),
    MenuEntry('Super Admins', 'superadmin-management', Icons.shield_outlined, superAdmin: true),
  ]),
];

/// All routes are loaded within the existing member portal shell, retaining
/// server-side role checks. These are not direct URLs to AJAX fragments.
String portalRoute(String route) {
  switch (route) {
    case 'scroller-admin': return 'bms-scroller-admin.php';
    case 'member-profiles': return 'member-profiles.php';
    case 'committee-management': return 'committee-management.php';
    case 'power-admin': return 'member-profiles.php?manage_power=1';
    default: return 'member-feed.php?open=${Uri.encodeQueryComponent(route)}';
  }
}
