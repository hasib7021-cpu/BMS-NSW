import 'package:flutter/material.dart';
import '../core/theme.dart';
import '../core/models.dart';

class BmsBackground extends StatelessWidget {
  final Widget child;
  const BmsBackground({super.key, required this.child});
  @override Widget build(BuildContext context) => Container(
    decoration: const BoxDecoration(gradient: LinearGradient(
      begin: Alignment.topLeft, end: Alignment.bottomRight,
      colors: [Color(0xFFF0FAFF), Color(0xFFF7FAFE), Color(0xFFF2F9F6)])),
    child: child,
  );
}

class BmsSectionHeading extends StatelessWidget {
  final String title, subtitle;
  final VoidCallback? onTap;
  const BmsSectionHeading({super.key, required this.title, this.subtitle = '', this.onTap});
  @override Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.fromLTRB(4, 14, 4, 12),
    child: Row(children: [Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18, color: BmsColors.navy)),
      if (subtitle.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 3), child: Text(subtitle, style: const TextStyle(color: BmsColors.muted, fontSize: 11))),
    ])), if (onTap != null) TextButton(onPressed: onTap, child: const Text('See all  →'))]),
  );
}

class GlassTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final Color color;
  final VoidCallback onTap;
  const GlassTile({super.key, required this.icon, required this.title, required this.onTap, this.color = BmsColors.blue});
  @override Widget build(BuildContext context) => InkWell(
    onTap: onTap, borderRadius: BorderRadius.circular(19),
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.white, borderRadius: BorderRadius.circular(19),
        border: Border.all(color: const Color(0xFFE6EEF6)),
        boxShadow: const [BoxShadow(color: Color(0x171B6A97), blurRadius: 15, offset: Offset(0, 7))],
      ),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Container(width: 43, height: 43, decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(15),
          gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [color.withValues(alpha: .13), color.withValues(alpha: .04)]),
          boxShadow: const [BoxShadow(color: Color(0x13FFFFFF), blurRadius: 8, offset: Offset(-2, -2))],
        ), child: Icon(icon, color: color, size: 24)),
        const SizedBox(height: 9),
        Text(title, maxLines: 2, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center,
          style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 9.2, height: 1.3)),
      ]),
    ),
  );
}

class FeedCard extends StatelessWidget {
  final FeedItem item;
  final IconData fallback;
  final VoidCallback onTap;
  const FeedCard({super.key, required this.item, required this.fallback, required this.onTap});
  @override Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(bottom: 11), decoration: softCard(radius: 20),
    child: InkWell(onTap: onTap, borderRadius: BorderRadius.circular(20),
      child: Padding(padding: const EdgeInsets.all(13), child: Row(children: [
        ClipRRect(borderRadius: BorderRadius.circular(15), child: Container(
          width: 74, height: 74, color: const Color(0xFFE7F4FB),
          child: item.image.startsWith('https://') ? Image.network(item.image, fit: BoxFit.cover,
            errorBuilder: (context, error, stack) => Icon(fallback, size: 30, color: BmsColors.blue))
            : Icon(fallback, size: 30, color: BmsColors.blue),
        )),
        const SizedBox(width: 13),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(item.category.toUpperCase(), style: const TextStyle(color: BmsColors.teal, fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 1)),
          const SizedBox(height: 4),
          Text(item.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13)),
          const SizedBox(height: 5),
          Text(item.date.isNotEmpty ? item.date : item.subtitle, maxLines: 1, overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 10.5, color: BmsColors.muted)),
        ])),
        const Icon(Icons.chevron_right_rounded, color: BmsColors.muted),
      ]))),
  );
}

class DotIndicators extends StatelessWidget {
  final int length, current;
  const DotIndicators({super.key, required this.length, required this.current});
  @override Widget build(BuildContext context) => Row(mainAxisAlignment: MainAxisAlignment.center,
    children: List.generate(length, (i) => AnimatedContainer(
      duration: const Duration(milliseconds: 180), margin: const EdgeInsets.symmetric(horizontal: 3),
      height: 6, width: i == current ? 21 : 6,
      decoration: BoxDecoration(color: i == current ? BmsColors.blue : const Color(0xFFD0DFE9), borderRadius: BorderRadius.circular(6)),
    )));
}

/// Swipe-only promotional placement: no auto-advance timer by design.
class ManualPromoCarousel extends StatefulWidget {
  final int section;
  final void Function(String route) onOpen;
  const ManualPromoCarousel({super.key, required this.section, required this.onOpen});
  @override State<ManualPromoCarousel> createState() => _ManualPromoCarouselState();
}

class _ManualPromoCarouselState extends State<ManualPromoCarousel> {
  int page = 0;
  @override Widget build(BuildContext context) {
    const promos = [
      ('Upcoming Events', 'See what is next', 'events', Icons.event_rounded),
      ('Latest News', 'Community stories', 'news', Icons.newspaper_rounded),
      ('Giving Back', 'Make a difference', 'fundraisings', Icons.favorite_rounded),
    ];
    final shift = widget.section % promos.length;
    return Column(children: [
      SizedBox(height: 76, child: PageView.builder(itemCount: 3,
        onPageChanged: (i) => setState(() => page = i),
        itemBuilder: (context, i) {
          final promo = promos[(i + shift) % 3];
          return InkWell(onTap: () => widget.onOpen(promo.$3), child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 2, vertical: 4),
            padding: const EdgeInsets.symmetric(horizontal: 17),
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(17),
              gradient: LinearGradient(colors: [
                const Color(0xFFDDF3FF), const Color(0xFFE4F8F1)]),
              border: Border.all(color: const Color(0xFFD7E9F3))),
            child: Row(children: [Icon(promo.$4, size: 28, color: BmsColors.blue), const SizedBox(width: 12),
              Expanded(child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start,
                children: [Text(promo.$1, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w900)),
                  Text(promo.$2, style: const TextStyle(fontSize: 10, color: BmsColors.muted))])),
              const Icon(Icons.arrow_forward_rounded, color: BmsColors.blue, size: 20)]),
          ));
        })),
      const SizedBox(height: 5), DotIndicators(length: 3, current: page),
    ]);
  }
}
