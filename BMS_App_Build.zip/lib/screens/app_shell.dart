import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../core/api.dart';
import '../core/models.dart';
import '../core/theme.dart';
import 'widgets.dart';
import 'menu_data.dart';
import 'portal_web.dart';

class AppShell extends StatefulWidget {
  final Member member;
  final BmsApi api;
  final bool demo;
  final VoidCallback onLogout;
  const AppShell({super.key, required this.member, required this.api, required this.demo, required this.onLogout});
  @override State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  DashboardData data = DemoContent.dashboard;
  int tab = -1, bannerIndex = 0;
  bool fetching = false;
  final search = TextEditingController();
  @override void initState() { super.initState(); if (!widget.demo) refresh(); }
  @override void dispose() { search.dispose(); super.dispose(); }

  Future<void> refresh() async {
    setState(() => fetching = true);
    try {
      final result = await widget.api.dashboard();
      if (mounted) setState(() => data = result);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not refresh: $e')));
    } finally { if (mounted) setState(() => fetching = false); }
  }

  void openRoute(String title, String route) {
    if (route == 'home') { setState(() => tab = -1); return; }
    if (route == 'events' || route == 'news') { setState(() => tab = 2); return; }
    if (route == 'alerts') {
      Navigator.of(context).push(MaterialPageRoute(builder: (_) => _ListScreen(title: 'Notifications', items: data.alerts,
        icon: Icons.notifications_outlined, onTap: (_) => openPortal('Notifications', 'member-feed.php?open=alerts')))); return;
    }
    openPortal(title, portalRoute(route));
  }

  void openPortal(String title, String path) {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => PortalWebScreen(
      title: title, path: path, sessionCookie: widget.api.sessionCookie, demo: widget.demo)));
  }

  Future<void> selectTab(int index) async {
    if (index == 3) {
      final url = Uri.parse(websiteBase);
      if (!await launchUrl(url, mode: LaunchMode.externalApplication) && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not open browser.')));
      }
      return;
    }
    if (index == 4) {
      final confirm = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
        title: const Text('Sign out?'), content: const Text('You can sign back in whenever you need.'),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Sign out'))],
      ));
      if (confirm == true) widget.onLogout();
      return;
    }
    setState(() => tab = index);
  }

  @override Widget build(BuildContext context) => Scaffold(
    body: BmsBackground(child: SafeArea(child: Center(child: ConstrainedBox(
      constraints: const BoxConstraints(maxWidth: 620),
      child: Column(children: [
        _header(),
        if (fetching) const LinearProgressIndicator(minHeight: 2),
        Expanded(child: IndexedStack(index: tab + 1, children: [
          _dashboard(), _menu(), _payments(), _eventsNews(),
        ])),
      ]),
    )))),
    bottomNavigationBar: SafeArea(top: false, child: Container(
      padding: const EdgeInsets.fromLTRB(4, 8, 4, 4),
      decoration: const BoxDecoration(color: Colors.white, boxShadow: [BoxShadow(color: Color(0x15124A70), blurRadius: 24, offset: Offset(0, -5))]),
      child: Row(children: [
        _nav(Icons.grid_view_rounded, 'Menu', 0),
        _nav(Icons.account_balance_wallet_outlined, 'Payments', 1),
        _nav(Icons.event_note_rounded, 'Events & News', 2),
        _nav(Icons.public_rounded, 'View Web', 3),
        _nav(Icons.logout_rounded, 'Logout', 4),
      ]),
    )),
  );

  Widget _nav(IconData icon, String label, int index) {
    final selected = tab == index;
    return Expanded(child: InkWell(onTap: () => selectTab(index), borderRadius: BorderRadius.circular(15),
      child: Container(padding: const EdgeInsets.symmetric(vertical: 6),
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(15),
          gradient: selected ? const LinearGradient(colors: [Color(0xFFE8F5FF), Color(0xFFEAFBF5)]) : null),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, color: selected ? BmsColors.blue : BmsColors.muted, size: 24),
          const SizedBox(height: 4),
          Text(label, maxLines: 1, style: TextStyle(fontSize: 9, fontWeight: selected ? FontWeight.w900 : FontWeight.w600,
            color: selected ? BmsColors.navy : BmsColors.muted)),
        ]),
      )));
  }

  Widget _header() => Container(
    color: Colors.white,
    padding: const EdgeInsets.fromLTRB(17, 9, 17, 10),
    child: Row(children: [
      InkWell(onTap: () => setState(() => tab = -1), child: Image.asset('assets/images/bms_logo.png', width: 46, height: 46)),
      const SizedBox(width: 11),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('BMS NSW', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: BmsColors.navy)),
        Text(widget.demo ? 'Interactive design preview' : 'Member Portal',
          style: const TextStyle(fontSize: 10, color: BmsColors.muted)),
      ])),
      if (widget.demo) Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
        decoration: BoxDecoration(color: const Color(0xFFFFF1D8), borderRadius: BorderRadius.circular(12)),
        child: const Text('DEMO', style: TextStyle(color: Color(0xFF9E6100), fontWeight: FontWeight.w900, fontSize: 9))),
      const SizedBox(width: 6),
      IconButton(onPressed: () => openRoute('Notifications', 'alerts'),
        icon: const Icon(Icons.notifications_none_rounded, color: BmsColors.navy)),
    ]),
  );

  Widget _dashboard() => RefreshIndicator(onRefresh: widget.demo ? () async {} : refresh,
    child: ListView(padding: const EdgeInsets.fromLTRB(17, 19, 17, 26), children: [
      _welcome(),
      const SizedBox(height: 18),
      _quickActions(),
      const SizedBox(height: 14),
      BmsSectionHeading(title: 'Community highlights', subtitle: 'Swipe to explore · manual navigation'),
      _manualBanners(),
      BmsSectionHeading(title: 'Upcoming events', subtitle: 'Your society calendar', onTap: () => setState(() => tab = 2)),
      if (data.events.isEmpty) _empty('The next event will be announced soon. Stay connected!'),
      ...data.events.take(3).map((e) => FeedCard(item: e, fallback: Icons.event_rounded,
        onTap: () => openPortal('Event details', 'member-feed.php?open=events&events_view=detail&event_id=${e.id}'))),
      BmsSectionHeading(title: 'Latest news', subtitle: 'Stories from BMS NSW', onTap: () => setState(() => tab = 2)),
      if (data.news.isEmpty) _empty('No published news at the moment.'),
      ...data.news.take(3).map((e) => FeedCard(item: e, fallback: Icons.newspaper_rounded,
        onTap: () => openPortal('News', 'member-feed.php?open=news'))),
    ]),
  );

  Widget _welcome() => Container(
    decoration: BoxDecoration(borderRadius: BorderRadius.circular(28), gradient: const LinearGradient(
      colors: [Color(0xFF10365D), Color(0xFF157BC2), Color(0xFF1AA69C)],
      begin: Alignment.topLeft, end: Alignment.bottomRight),
      boxShadow: const [BoxShadow(color: Color(0x32147BC1), blurRadius: 24, offset: Offset(0, 11))]),
    padding: const EdgeInsets.all(22),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [const Icon(Icons.waving_hand_rounded, color: Color(0xFFFFD880), size: 19),
        const SizedBox(width: 7), const Text('WELCOME BACK', style: TextStyle(color: Color(0xFFC9E8FF), letterSpacing: 1.4, fontSize: 10, fontWeight: FontWeight.w800)),
        const Spacer(), const Icon(Icons.auto_awesome_rounded, color: Colors.white70)]),
      const SizedBox(height: 13),
      Text(widget.member.name, maxLines: 2, overflow: TextOverflow.ellipsis,
        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 23)),
      const SizedBox(height: 6),
      Text(widget.member.membership, style: const TextStyle(color: Color(0xFFDAF3FF), fontSize: 11)),
      const SizedBox(height: 19),
      Row(children: [
        _welcomeChip(Icons.verified_rounded, 'Member Community'),
        const SizedBox(width: 9),
        _welcomeChip(Icons.location_on_outlined, 'New South Wales'),
      ]),
    ]),
  );

  Widget _welcomeChip(IconData icon, String label) => Flexible(child: Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
    decoration: BoxDecoration(color: Colors.white.withValues(alpha: .13), border: Border.all(color: Colors.white24), borderRadius: BorderRadius.circular(12)),
    child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(icon, color: Colors.white, size: 14), const SizedBox(width: 5),
      Flexible(child: Text(label, maxLines: 1, overflow: TextOverflow.ellipsis,
        style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w800)))]),
  ));

  Widget _quickActions() => Row(children: [
    _quick(Icons.credit_card_rounded, 'Renew', () => setState(() => tab = 1)),
    _quick(Icons.event_available_rounded, 'Events', () => setState(() => tab = 2)),
    _quick(Icons.how_to_vote_rounded, 'Voting', () => openRoute('Elections', 'elections')),
    _quick(Icons.groups_rounded, 'Members', () => openRoute('Members', 'members')),
  ]);

  Widget _quick(IconData icon, String label, VoidCallback onTap) => Expanded(child: Padding(
    padding: const EdgeInsets.symmetric(horizontal: 4), child: GlassTile(icon: icon, title: label, onTap: onTap)));

  Widget _manualBanners() {
    final slides = [
      ('BMS NSW Events', 'Connect. Learn. Celebrate.', Icons.event_available_rounded, const Color(0xFF0D6FB2)),
      ('Society News', 'Important updates from your community.', Icons.campaign_outlined, const Color(0xFF178F88)),
      ('Giving Back', 'Support our fundraising campaigns.', Icons.volunteer_activism_rounded, const Color(0xFF8063BE)),
      ('Photo Gallery', 'Memories from our society.', Icons.photo_library_rounded, const Color(0xFFBD7A38)),
    ];
    return Column(children: [
      SizedBox(height: 146, child: PageView.builder(itemCount: slides.length,
        onPageChanged: (i) => setState(() => bannerIndex = i),
        itemBuilder: (context, i) {
          final s = slides[i];
          return InkWell(onTap: () => openRoute(s.$1, ['events','news','fundraisings','gallery'][i]),
            child: Container(margin: const EdgeInsets.symmetric(horizontal: 2, vertical: 3), padding: const EdgeInsets.all(19),
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(22),
                gradient: LinearGradient(colors: [s.$4, BmsColors.navy]),
                boxShadow: const [BoxShadow(color: Color(0x24154B77), blurRadius: 12, offset: Offset(0, 5))]),
              child: Row(children: [Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center,
                children: [Text(s.$1, style: const TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 7), Text(s.$2, style: const TextStyle(color: Colors.white70, fontSize: 11)),
                  const SizedBox(height: 12), const Text('EXPLORE  →', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 10))])),
                Icon(s.$3, size: 68, color: Colors.white.withValues(alpha: .24))]),
            ));
        })),
      const SizedBox(height: 8), DotIndicators(length: slides.length, current: bannerIndex),
    ]);
  }

  Widget _menu() => ListView(padding: const EdgeInsets.fromLTRB(14, 14, 14, 26), children: [
    const BmsSectionHeading(title: 'Explore your portal', subtitle: 'Everything you need, beautifully organized'),
    Padding(padding: const EdgeInsets.only(bottom: 18), child: TextField(controller: search,
      onChanged: (_) => setState(() {}),
      decoration: const InputDecoration(hintText: 'Find a feature...', prefixIcon: Icon(Icons.search_rounded)))),
    ...menuGroups.where((group) => group.entries.any((e) => e.allowed(widget.member))).map((group) {
      final filtered = group.entries.where((e) => e.allowed(widget.member) &&
        e.title.toLowerCase().contains(search.text.toLowerCase())).toList();
      if (filtered.isEmpty) return const SizedBox.shrink();
      final idx = menuGroups.indexOf(group);
      return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        BmsSectionHeading(title: group.title, subtitle: group.subtitle),
        GridView.builder(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
          itemCount: filtered.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 5, mainAxisSpacing: 9, crossAxisSpacing: 7, childAspectRatio: .68),
          itemBuilder: (context, i) {
            final entry = filtered[i];
            return GlassTile(icon: entry.icon, title: entry.title, color: [BmsColors.blue, BmsColors.teal,
              const Color(0xFF765DB8), const Color(0xFFDA8A3C), BmsColors.blue][i % 5],
              onTap: () => openRoute(entry.title, entry.route));
          }),
        const SizedBox(height: 18),
        if (search.text.isEmpty && (idx == 0 || idx == 2 || idx == 3 || idx == 4))
          _miniBanner(idx),
      ]);
    }),
  ]);

  Widget _miniBanner(int idx) => Padding(
    padding: const EdgeInsets.only(bottom: 14),
    child: ManualPromoCarousel(section: idx, onOpen: (route) => openRoute('Explore', route)),
  );

  Widget _payments() => ListView(padding: const EdgeInsets.all(17), children: [
    const BmsSectionHeading(title: 'Payments & giving', subtitle: 'Secure payments through the existing BMS NSW website'),
    _payment(Icons.workspace_premium_rounded, 'Membership renewal', 'Renew your annual membership or review your status.', 'membership'),
    _payment(Icons.person_add_alt_1_rounded, 'New membership', 'Apply for membership with the current registration system.', 'join'),
    _payment(Icons.confirmation_number_outlined, 'Event registration', 'Register and pay for society events.', 'events'),
    _payment(Icons.volunteer_activism_rounded, 'Donation campaigns', 'Support fundraising and charitable initiatives.', 'fundraisings'),
    const SizedBox(height: 12),
    const Text('Payments are processed by the existing website workflow. No card data is stored in the Flutter app.',
      style: TextStyle(fontSize: 11, color: BmsColors.muted)),
  ]);

  Widget _payment(IconData icon, String title, String desc, String route) => Container(
    margin: const EdgeInsets.only(bottom: 12), decoration: softCard(),
    child: InkWell(borderRadius: BorderRadius.circular(22),
      onTap: () => openPortal(title, route == 'join' ? 'join-bms.php' : portalRoute(route)),
      child: Padding(padding: const EdgeInsets.all(17), child: Row(children: [
        Container(width: 54, height: 54, decoration: BoxDecoration(color: const Color(0xFFE6F6FF), borderRadius: BorderRadius.circular(16)),
          child: Icon(icon, color: BmsColors.blue, size: 27)),
        const SizedBox(width: 13),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 14)),
          const SizedBox(height: 4), Text(desc, style: const TextStyle(color: BmsColors.muted, fontSize: 11)),
        ])), const Icon(Icons.arrow_forward_ios_rounded, size: 15, color: BmsColors.blue),
      ])),
    ),
  );

  Widget _eventsNews() => DefaultTabController(length: 2, child: Column(children: [
    const Padding(padding: EdgeInsets.fromLTRB(17, 15, 17, 6), child: BmsSectionHeading(title: 'Events & News', subtitle: 'Latest updates from your society')),
    const TabBar(labelColor: BmsColors.blue, unselectedLabelColor: BmsColors.muted, tabs: [
      Tab(text: 'Events', icon: Icon(Icons.event_available_outlined)),
      Tab(text: 'News', icon: Icon(Icons.newspaper_outlined)),
    ]),
    Expanded(child: TabBarView(children: [
      _listContent(data.events, 'No upcoming events. Check back soon!', Icons.event_rounded, 'events'),
      _listContent(data.news, 'No published news right now.', Icons.newspaper_rounded, 'news'),
    ])),
  ]));

  Widget _listContent(List<FeedItem> items, String emptyText, IconData icon, String route) =>
    ListView(padding: const EdgeInsets.all(17), children: [
      if (items.isEmpty) _empty(emptyText),
      ...items.map((e) => FeedCard(item: e, fallback: icon,
        onTap: () => openPortal(e.title, route == 'events'
          ? 'member-feed.php?open=events&events_view=detail&event_id=${e.id}'
          : 'member-feed.php?open=news'))),
      const SizedBox(height: 12),
      OutlinedButton.icon(onPressed: () => openPortal('All ${route == 'events' ? 'Events' : 'News'}', portalRoute(route)),
        icon: const Icon(Icons.open_in_new_rounded), label: Text('Open full ${route == 'events' ? 'event calendar' : 'news centre'}')),
    ]);

  Widget _empty(String text) => Container(padding: const EdgeInsets.all(24),
    decoration: softCard(), child: Column(children: [const Icon(Icons.event_note_outlined, size: 36, color: BmsColors.blue),
      const SizedBox(height: 10), Text(text, textAlign: TextAlign.center, style: const TextStyle(color: BmsColors.muted, fontSize: 12))]));
}

class _ListScreen extends StatelessWidget {
  final String title;
  final List<FeedItem> items;
  final IconData icon;
  final void Function(FeedItem) onTap;
  const _ListScreen({required this.title, required this.items, required this.icon, required this.onTap});
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(title)),
    body: ListView(padding: const EdgeInsets.all(17), children: [
      ...items.map((item) => FeedCard(item: item, fallback: icon, onTap: () => onTap(item))),
      if (items.isEmpty) const Center(child: Padding(padding: EdgeInsets.all(30), child: Text('No notifications yet.'))),
    ]),
  );
}
