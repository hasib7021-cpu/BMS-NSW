# BMS NSW Member App — Flutter Prototype + PHP API Bridge

**Release:** v0.1.0 (developer preview / foundation, **not a production-ready App Store release**)

আপনার `for aps.zip`-এর PHP এবং SQL structure দেখে এই প্রজেক্ট তৈরি। এটি নতুন Database বানায় না। `server/app-api.php` বর্তমান `members`, `portal_events_feed`, `portal_news_feed`, `notifications`, `membership_payments`, `membership_renewals` টেবিল থেকেই তথ্য পড়ে। পুরোনো Member Portal-এর মূল PHP ফাইল পরিবর্তন করা হয়নি।

## কী তৈরি হয়েছে

- Flutter splash screen, BMS logo, native login UI, secure session storage
- Member Dashboard: welcome card, quick actions, native upcoming events, news, notifications
- পাঁচটি bottom navigation action: Menu, Payments, Events & News, View Web, Logout
- Five-column 3D-shadow menu cards, grouped menu headings, feature search
- Admin/Super Admin menu sections only when the server returns an admin role
- Manual swipe promotional carousels; কোনো auto-scroll নেই
- Membership renewal, new registration, event registration, donations, elections, messages, mentoring ইত্যাদির জন্য **existing authenticated PHP portal bridge**
- API-driven login, session restoration, logout, dashboard data
- Browser-only interactive preview + screenshots in `preview/`
- Existing website URL opens in the phone browser

## কী এখনো সম্পূর্ণ Native নয়

বর্তমান PHP portal-এর সব কাজ native Flutter-এ নতুন করে লেখা হয়নি। Payments, registration, donation, voting, profile edit, messaging, admin tools ইত্যাদি **in-app WebView bridge** দিয়ে existing website-এ চলবে, live setup ও testing-এর পর। Payment processing Flutter-এ নতুনভাবে implement করা হয়নি। Push notification (FCM/APNs), offline queue, native deep links, app store signing, privacy disclosures, payment policy review, biometric sign-in, exhaustive QA এখনও বাকি।

এটি client-কে UI demo দেখানো এবং API integration শুরু করার জন্য, final production release নয়।

## A. Flutter চালু করুন (Windows / macOS)

1. Flutter stable SDK এবং Android Studio install করুন। iOS build করতে macOS + Xcode প্রয়োজন।
2. এই folder খুলে Terminal-এ চালান:

```bash
flutter create --platforms=android,ios --org au.com.bmsnsw .
flutter pub get
flutter run --dart-define=ENABLE_DEMO=true
```

3. **Preview as Member** অথবা **Preview as Super Admin** দিয়ে sample UI দেখুন। Demo mode কখনো live DB-তে login করে না।
4. Android release-এর জন্য generated `android/app/src/main/AndroidManifest.xml`-এ `<manifest>`-এর নিচে (application-এর বাইরে) এই permission রাখুন:

```xml
<uses-permission android:name="android.permission.INTERNET" />
```

5. Real login চালাতে প্রথমে staging server-এ API setup করুন, তারপর:

```bash
flutter run --dart-define=BMS_API_BASE=https://YOUR-STAGING-DOMAIN/app-api.php
```

**Production build-এ `ENABLE_DEMO=true` দেবেন না।** Demo buttons default-এ hidden থাকে।

## B. API setup (staging first)

1. Website root-এ `config.php` এবং `membership-cycle.php` আগে থেকেই আছে।
2. `server/app-api.php` **শুধু** staging website root-এ `app-api.php` নামে Upload করুন।
3. `https://YOUR-STAGING-DOMAIN/app-api.php?action=me` open করলে লগইন ছাড়া 401 JSON response পাওয়া উচিত। 500 বা HTML হলে staging PHP error log দেখুন।
4. Flutter build-এ `BMS_API_BASE` staging URL দিন। Valid member account দিয়ে Login করে dashboard দেখুন।
5. Member, Admin, Super Admin এবং expired/inactive account দিয়ে role/access test করুন।
6. **Live production-এ upload করার আগে** security review, rate limiting, login audit, payment flow, session-cookie behavior, WebView redirects ও permissions test করতে হবে।

**No database migration.** Existing member data বা password export app-এ অন্তর্ভুক্ত করা হয়নি। `config.php` ও SQL export এই delivery ZIP-এ রাখা হয়নি।

## C. Build

```bash
flutter analyze
flutter test
flutter build apk --release --dart-define=BMS_API_BASE=https://bms-nsw.com.au/app-api.php
flutter build appbundle --release --dart-define=BMS_API_BASE=https://bms-nsw.com.au/app-api.php
```

Android App Bundle (`.aab`) Google Play Console-এর জন্য। iOS App Store Connect build macOS-এ Xcode signing এবং `flutter build ipa` দিয়ে করতে হবে। App ID, legal ownership, signing keys, icon, screenshots, privacy policy, data safety, and push entitlement configure করতে হবে। **এই ZIP-এ APK/IPA নেই** কারণ Flutter SDK ও platform toolchains এই environment-এ নেই।

## D. Architecture

```text
Flutter Native UI
  ├─ API: app-api.php (read-only data + session login/logout)
  │     └─ Existing MySQL tables on BMS NSW website
  └─ Legacy feature bridge (WebView)
        └─ Existing member-feed.php / existing payment, voting, admin modules
```

**একই Database:** Website থেকে news/event/profile update হলে API-driven mobile screen-এ next refresh-এ একই তথ্য আসবে। WebView-তে কাজ করলে existing website-এর DB-তেই update হয়। Native Flutter write APIs তৈরি করার সময় existing server validation/permissions reuse করতে হবে।

## E. Important testing checklist

- [ ] PHP session login, logout, session expiry, password-change-required
- [ ] Android and iOS WebView session sharing (real device)
- [ ] Member vs Admin vs Super Admin menus, server-side access enforcement
- [ ] Annual vs Lifetime Membership and voting eligibility
- [ ] Stripe Checkout + 3D Secure + return redirects; offline payment
- [ ] Event registration, donation contribution, receipts
- [ ] Native push token registration and server-side notification delivery
- [ ] Privacy/consent, crash monitoring, accessibility, small screens
- [ ] App Store review requirements, especially native functionality and payments

## F. Expected time for full production app

একজন অভিজ্ঞ Flutter + PHP developer দিনে ৮ ঘণ্টা দিলে, বিদ্যমান live system-এর উপর **প্রায় ৮–১২ সপ্তাহ (৩২০–৪৮০ ঘণ্টা)** ধরে পরিকল্পনা করা বাস্তবসম্মত। Push notifications, all-native payments/voting, QA, security review এবং App Store submission-এ অতিরিক্ত সময় লাগতে পারে। ১০ দিনে full production release বাস্তবসম্মত নয়।

## G. Important notes

- **Never** upload `for aps.zip`, full SQL export, config credentials, passwords, or user database inside the mobile app package.
- Keep role permissions server-side; hiding an Admin tile is not a security boundary.
- App Store publication may reject a thin website wrapper; progressively replace legacy WebView pages with native Flutter flows.
- App changes to data must go through the same backend validation and database as the website.
