from pathlib import Path
import re, shutil

root = Path(__file__).resolve().parent.parent
manifest = root / 'android/app/src/main/AndroidManifest.xml'
assert manifest.is_file(), 'AndroidManifest.xml missing; run flutter create first'
s = manifest.read_text(encoding='utf-8')
s, count = re.subn(r'android:label="[^"]*"', 'android:label="BMS NSW Members"', s, count=1)
assert count == 1, 'Could not set Android app name'
if 'android.permission.INTERNET' not in s:
    s, count = re.subn(r'(<manifest\b[^>]*>)', r'\1\n    <uses-permission android:name="android.permission.INTERNET" />', s, count=1)
    assert count == 1, 'Could not insert Android internet permission'
manifest.write_text(s, encoding='utf-8')
for density in ('mdpi','hdpi','xhdpi','xxhdpi','xxxhdpi'):
    dest = root / f'android/app/src/main/res/mipmap-{density}/ic_launcher.png'
    dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(root / f'android-icons/{density}.png',dest)
print('Android app name, launcher icons, and internet permission prepared.')
