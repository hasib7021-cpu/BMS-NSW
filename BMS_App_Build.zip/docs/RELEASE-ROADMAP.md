# Roadmap to Android + iOS production

## Stage 1 — Prototype and API (1–2 weeks)
- Flutter native UI, role-aware menu, design sign-off
- Secure API login, session handling, data sync; stage on separate domain
- QA on Android phones and iPhones

## Stage 2 — Core member workflows (2–3 weeks)
- Native member directory, profile, announcements, events and event registration
- Membership renewal and registration; payment handoff / Stripe policy review
- Donation campaign payments and transaction receipts

## Stage 3 — Voting, notifications, admin (2–3 weeks)
- Voting eligibility and election ballots with server-side one-vote constraints
- Firebase Cloud Messaging + Apple Push Notification service and device-token table
- Admin announcements, targeted broadcasts and notification preferences
- Profile updates, mentor and member messaging flows

## Stage 4 — Production QA and publication (2–4 weeks)
- Penetration/security review; permissions, privacy, rate limiting
- Payment sandbox/live QA and refunds; account deletion path and privacy policy
- Crash monitoring, accessibility, responsive layouts, app icons and splash
- Google Play closed test, Apple TestFlight, signing and store submission

**Estimate:** ~8–12 weeks (320–480 development hours) for a single experienced developer, potentially longer for complex native workflows, policy approvals or production bug fixes. This package is Stage 1 foundation only.
