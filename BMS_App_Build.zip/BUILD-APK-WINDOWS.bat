@echo off
setlocal
where flutter >nul 2>nul
if errorlevel 1 (
  echo Flutter SDK not found. Install Flutter and Android Studio first.
  pause
  exit /b 1
)
flutter create --platforms=android --org au.com.bmsnsw . || exit /b 1
python scripts\prepare_android.py || exit /b 1
flutter pub get || exit /b 1
flutter build apk --release --dart-define=ENABLE_DEMO=true || exit /b 1
copy /Y build\app\outputs\flutter-apk\app-release.apk build\app\outputs\flutter-apk\BMS-NSW-Member-App-DEMO.apk
pause
