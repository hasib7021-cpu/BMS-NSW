<?php
/**
 * BMS NSW Mobile API v0.1 (read-only member content + session login/logout).
 * Upload next to the existing config.php and membership-cycle.php in website root.
 * Uses existing members / portal tables. No SQL migration is required.
 *
 * Important: this is a migration bridge, NOT a complete mobile backend.
 * Write operations (payments, votes, edits) remain on existing PHP pages.
 */
declare(strict_types=1);
ini_set('display_errors', '0');
ini_set('session.use_strict_mode', '1');
ini_set('session.use_only_cookies', '1');
session_set_cookie_params([
    'lifetime' => 0, 'path' => '/', 'secure' => true,
    'httponly' => true, 'samesite' => 'Lax',
]);
session_start();
header('Content-Type: application/json; charset=UTF-8');
header('Cache-Control: private, no-store, max-age=0');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');

function mobile_out(int $code, array $payload): void {
    http_response_code($code);
    echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}
function mobile_image($path): string {
    $path = trim((string)$path);
    if ($path === '' || str_contains($path, '..') || str_starts_with($path, '//')) return '';
    if (preg_match('~^https://bms-nsw\.com\.au/~i', $path)) return $path;
    if (preg_match('~^(?:img|uploads)/[a-zA-Z0-9_./-]+$~', $path)) return 'https://bms-nsw.com.au/' . $path;
    return '';
}
function mobile_text($text): string {
    return trim(html_entity_decode(strip_tags((string)$text), ENT_QUOTES | ENT_HTML5, 'UTF-8'));
}
function mobile_can_vote(PDO $pdo, array $member): bool {
    $membership = strtolower(trim((string)($member['membership_type'] ?? '') . ' ' . (string)($member['member_package'] ?? '')));
    if (str_contains($membership, 'lifetime')) return true;
    require_once __DIR__ . '/membership-cycle.php';
    $cycle = bms_membership_cycle_for_date();
    $newCycle = bms_new_membership_cycle_for_date();
    $id = (int)$member['id'];
    try {
        $p = $pdo->prepare("SELECT 1 FROM membership_payments WHERE member_id = ? AND LOWER(payment_status) = 'paid' AND
            (payment_cycle = ? OR (payment_type = 'joining_fee' AND payment_cycle = ?) OR
             (payment_cycle IS NULL AND payment_type = 'renewal' AND COALESCE(paid_at, created_at) >= ?
              AND COALESCE(paid_at, created_at) < DATE_ADD(?, INTERVAL 1 DAY))) LIMIT 1");
        $p->execute([$id, $cycle['key'], $newCycle['key'], $cycle['start'] . ' 00:00:00', $cycle['expiry'] . ' 00:00:00']);
        if ($p->fetchColumn()) return true;
        $r = $pdo->prepare("SELECT 1 FROM membership_renewals WHERE member_id = ? AND LOWER(renewal_status) = 'paid' AND
            (payment_cycle = ? OR (payment_cycle IS NULL AND paid_at >= ? AND paid_at < DATE_ADD(?, INTERVAL 1 DAY))) LIMIT 1");
        $r->execute([$id, $cycle['key'], $cycle['start'] . ' 00:00:00', $cycle['expiry'] . ' 00:00:00']);
        return (bool)$r->fetchColumn();
    } catch (Throwable $e) {
        error_log('Mobile API eligibility lookup failed: ' . $e->getMessage());
        return false;
    }
}
function mobile_member(PDO $pdo, array $m): array {
    return [
        'id' => (int)$m['id'],
        'name' => mobile_text($m['full_name'] ?? ''),
        'email' => (string)($m['email'] ?? ''),
        'role' => (string)($m['role'] ?? 'member'),
        'membership' => mobile_text($m['member_package'] ?: ($m['membership_type'] ?? 'Membership')),
        'photo' => mobile_image($m['profile_image'] ?? ''),
        'can_vote' => mobile_can_vote($pdo, $m),
    ];
}
function mobile_require_member(PDO $pdo): array {
    $id = (int)($_SESSION['member_id'] ?? 0);
    if ($id < 1) mobile_out(401, ['ok' => false, 'error' => 'Please sign in again.']);
    $q = $pdo->prepare('SELECT id, full_name, email, role, status, membership_type, member_package, profile_image FROM members WHERE id = ? LIMIT 1');
    $q->execute([$id]);
    $member = $q->fetch(PDO::FETCH_ASSOC);
    if (!$member || !bms_account_status_allows_login((string)$member['status'])) {
        mobile_out(401, ['ok' => false, 'error' => 'Your session is no longer active.']);
    }
    return $member;
}
function mobile_dashboard(PDO $pdo, int $memberId): array {
    $tz = new DateTimeZone('Australia/Sydney');
    $today = (new DateTimeImmutable('now', $tz))->format('Y-m-d');
    $e = $pdo->prepare("SELECT id, title, description, category, event_date, location, image_path FROM portal_events_feed
      WHERE status = 'published' AND event_date >= ? ORDER BY event_date ASC, id ASC LIMIT 10");
    $e->execute([$today]);
    $events = [];
    foreach ($e->fetchAll(PDO::FETCH_ASSOC) as $r) {
        $events[] = ['id' => (int)$r['id'], 'title' => mobile_text($r['title']),
            'subtitle' => mobile_text($r['location'] ?: $r['description']), 'date' => (string)$r['event_date'],
            'image' => mobile_image($r['image_path']), 'category' => mobile_text($r['category'])];
    }
    $n = $pdo->query("SELECT id, title, excerpt, image_path, published_at FROM portal_news_feed
      WHERE status = 'published' AND show_on_member_feed = 1 ORDER BY published_at DESC, id DESC LIMIT 10");
    $news = [];
    foreach ($n->fetchAll(PDO::FETCH_ASSOC) as $r) {
        $news[] = ['id' => (int)$r['id'], 'title' => mobile_text($r['title']),
            'subtitle' => mobile_text($r['excerpt']), 'date' => substr((string)$r['published_at'], 0, 10),
            'image' => mobile_image($r['image_path']), 'category' => 'Society news'];
    }
    $a = $pdo->prepare('SELECT id, title, message, created_at FROM notifications WHERE member_id = ? ORDER BY created_at DESC, id DESC LIMIT 10');
    $a->execute([$memberId]);
    $alerts = [];
    foreach ($a->fetchAll(PDO::FETCH_ASSOC) as $r) {
        $alerts[] = ['id' => (int)$r['id'], 'title' => mobile_text($r['title']),
            'subtitle' => mobile_text($r['message']), 'date' => substr((string)$r['created_at'], 0, 10),
            'image' => '', 'category' => 'Notification'];
    }
    return ['events' => $events, 'news' => $news, 'alerts' => $alerts];
}

try {
    require_once __DIR__ . '/config.php';
    require_once __DIR__ . '/membership-cycle.php';
    if (!isset($pdo) || !($pdo instanceof PDO)) throw new RuntimeException('Database connection unavailable');
    $action = (string)($_GET['action'] ?? '');
    $method = (string)($_SERVER['REQUEST_METHOD'] ?? 'GET');
    if ($action === 'login') {
        if ($method !== 'POST') mobile_out(405, ['ok' => false, 'error' => 'Method not allowed']);
        $body = json_decode((string)file_get_contents('php://input'), true);
        if (!is_array($body)) mobile_out(400, ['ok' => false, 'error' => 'Invalid request']);
        $email = trim((string)($body['email'] ?? ''));
        $password = (string)($body['password'] ?? '');
        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $password === '') {
            mobile_out(400, ['ok' => false, 'error' => 'Enter a valid email and password.']);
        }
        // Per-session throttle; configure additional IP-based rate limiting at CDN/WAF.
        $attempts = (int)($_SESSION['mobile_login_attempts'] ?? 0);
        $first = (int)($_SESSION['mobile_login_first'] ?? time());
        if (time() - $first > 900) { $attempts = 0; $first = time(); }
        if ($attempts >= 8) mobile_out(429, ['ok' => false, 'error' => 'Too many attempts. Try again later.']);
        $_SESSION['mobile_login_first'] = $first;
        $_SESSION['mobile_login_attempts'] = $attempts + 1;
        $q = $pdo->prepare('SELECT id, full_name, email, password, role, status, must_change_password, membership_type, member_package, profile_image FROM members WHERE email = ? LIMIT 1');
        $q->execute([$email]);
        $member = $q->fetch(PDO::FETCH_ASSOC);
        if (!$member || !password_verify($password, (string)$member['password']) ||
            !bms_account_status_allows_login((string)$member['status'])) {
            mobile_out(401, ['ok' => false, 'error' => 'Incorrect credentials or inactive account.']);
        }
        if ((int)$member['must_change_password'] === 1) {
            mobile_out(403, ['ok' => false, 'error' => 'Please change your temporary password on the website before using the app.']);
        }
        session_regenerate_id(true);
        $_SESSION['member_id'] = (int)$member['id'];
        $_SESSION['member_name'] = $member['full_name'];
        $_SESSION['member_email'] = $member['email'];
        $_SESSION['member_role'] = $member['role'];
        unset($_SESSION['mobile_login_attempts'], $_SESSION['mobile_login_first']);
        mobile_out(200, ['ok' => true, 'member' => mobile_member($pdo, $member)]);
    }
    if ($action === 'logout') {
        if ($method !== 'POST') mobile_out(405, ['ok' => false, 'error' => 'Method not allowed']);
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 3600, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
        }
        session_destroy();
        mobile_out(200, ['ok' => true]);
    }
    if ($method !== 'GET') mobile_out(405, ['ok' => false, 'error' => 'Method not allowed']);
    $member = mobile_require_member($pdo);
    if ($action === 'me') mobile_out(200, ['ok' => true, 'member' => mobile_member($pdo, $member)]);
    if ($action === 'dashboard') mobile_out(200, ['ok' => true] + mobile_dashboard($pdo, (int)$member['id']));
    mobile_out(404, ['ok' => false, 'error' => 'Unknown endpoint']);
} catch (Throwable $e) {
    error_log('BMS Mobile API error: ' . $e->getMessage());
    mobile_out(500, ['ok' => false, 'error' => 'Service temporarily unavailable.']);
}
